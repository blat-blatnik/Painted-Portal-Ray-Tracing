#ifndef MAINVIEW_H
#define MAINVIEW_H

#include <QKeyEvent>
#include <QMouseEvent>
#include <QOpenGLWidget>
#include <QOpenGLFunctions_4_3_Core>
#include <QOpenGLDebugLogger>
#include <QTimer>
#include <QElapsedTimer>
#include <memory>
#include <vector>
#include "glm/glm.hpp"
#include "glm/ext.hpp"
using namespace glm;

class MainView : public QOpenGLWidget, protected QOpenGLFunctions_4_3_Core {
    Q_OBJECT

public:
    MainView(QWidget *parent = 0);
    ~MainView();

    void initializeGL();
    void resizeGL(int newWidth, int newHeight);
    void paintGL();

    // Functions for keyboard input events
    void keyPressEvent(QKeyEvent *ev);
    void keyReleaseEvent(QKeyEvent *ev);

    // Function for mouse input events
    void mouseDoubleClickEvent(QMouseEvent *ev);
    void mouseMoveEvent(QMouseEvent *ev);
    void mousePressEvent(QMouseEvent *ev);
    void mouseReleaseEvent(QMouseEvent *ev);
    void wheelEvent(QWheelEvent *ev);
    void leaveEvent(QEvent *ev);

public slots:
    void onMessageLogged( QOpenGLDebugMessage Message );

public:
    enum GameMode {
        PlayMode,
        BuildMode
    };

    QOpenGLDebugLogger debugLogger;
    QTimer timer; // timer used for animation
    QElapsedTimer iTimer;

    bool shiftIsDown = false;
    bool ctrlIsDown = false;
    bool spaceIsDown = false;
    bool wIsDown = false;
    bool aIsDown = false;
    bool sIsDown = false;
    bool dIsDown = false;
    float cameraFovy = 60; // camera orientation

    QVector<quint8> imageToBytes(QImage image);






























    char *readWholeFile(const char *filename);

    // For example GL_ARRAY_BUFFER, or GL_SHADER_STORAGE_BUFFER..
    typedef GLenum BufferSlot;

    // For example GL_FLOAT, or GL_FLOAT_VEC2, ..
    typedef GLenum ShaderDataType;

    // Must be one of GL_NEAREST, GL_LINEAR, or GL_LINEAR_MIPMAP_LINEAR.
    typedef GLenum TextureFilter;

    // For example GL_RGBA8, or GL_RGB16F
    typedef GLenum TextureStoreFormat;

    // Represents an OpenGL buffer object.
    typedef GLuint GpuBuffer;

    // Represents an OpenGL Texture2D object.
    typedef GLuint Texture;

    // Represents an OpenGL Texture2DArray object.
    typedef GLuint TextureArray;

    // Represents an OpenGL ShaderProgram object.
    typedef GLuint Shader;

    // glGenBuffers + glBufferData
    GpuBuffer createGpuBuffer(void *data, size_t size);
    // glBufferData
    void recreateGpuBuffer(GpuBuffer buffer, const void *data, size_t size);
    // glBufferSubData
    void updateGpuBuffer(GpuBuffer buffer, size_t offset, const void *data, size_t size);
    // glBindBuffer or glBindBufferBase depending on the slot and the binding
    void bindGpuBuffer(GpuBuffer buffer, BufferSlot slot, int binding);
    // glBindBufferRange
    void bindGpuBuffer(GpuBuffer buffer, BufferSlot slot, int binding, size_t offset, size_t size);
    // glDeleteBuffers
    void destroyGpuBuffer(GpuBuffer buffer);

    // glGenTextures + glTexImage2D
    Texture createTexture(const void *pixels, uint width, uint height, TextureStoreFormat internalFormat);
    // Reads the pixels from the given image file and then calls createTexture from them
    Texture loadTexture(const char *filename, TextureStoreFormat internalFormat);
    // glActiveTexture + glBindTexture
    void bindTexture(Texture tex, uint unit);
    // glDeleteTextures
    void destroyTexture(Texture tex);

    // glGenTextures + glTexStorage3D + glTexSubImage3D for each sub image in the array
    TextureArray loadTextureArray(const char *filenames[], uint numFilenames, TextureStoreFormat internalFormat);
    // glActiveTexture + glBindTexture
    void bindTextureArray(TextureArray tex, uint unit);
    // glDeleteTextures
    void destroyTextureArray(TextureArray tex);

    // Loads and compiles a shader program from the specified vertex and fragement shader.
    // If compile or link errors occur they are printed to stdout.
    Shader loadShader(const char *vertFile, const char *fragFile);
    // glUseProgram
    void bindShader(Shader s);
    // glDeleteProgram
    void destroyShader(Shader s);
    // Calls the appropriate glUniform* based on the 'type'.
    void setUniform(Shader s, uint location, ShaderDataType type, const void *value, size_t valueSize);

    //
    // Convinience functions that wraps setUniform above based on the type.
    //
    template <class T> inline void setUniform(Shader s, uint location, ShaderDataType type, const T &value) {
        setUniform(s, location, type, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, float value) {
        setUniform(s, location, GL_FLOAT, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, vec2 value) {
        setUniform(s, location, GL_FLOAT_VEC2, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, vec3 value) {
        setUniform(s, location, GL_FLOAT_VEC3, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, vec4 value) {
        setUniform(s, location, GL_FLOAT_VEC4, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, mat2 value) {
        setUniform(s, location, GL_FLOAT_MAT2, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, mat3 value) {
        setUniform(s, location, GL_FLOAT_MAT3, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, mat4 value) {
        setUniform(s, location, GL_FLOAT_MAT4, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, int value) {
        setUniform(s, location, GL_INT, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, ivec2 value) {
        setUniform(s, location, GL_INT_VEC2, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, ivec3 value) {
        setUniform(s, location, GL_INT_VEC3, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, ivec4 value) {
        setUniform(s, location, GL_INT_VEC4, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, uint value) {
        setUniform(s, location, GL_UNSIGNED_INT, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, uvec2 value) {
        setUniform(s, location, GL_UNSIGNED_INT_VEC2, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, uvec3 value) {
        setUniform(s, location, GL_UNSIGNED_INT_VEC3, &value, sizeof(value));
    }
    inline void setUniform(Shader s, uint location, uvec4 value) {
        setUniform(s, location, GL_UNSIGNED_INT_VEC4, &value, sizeof(value));
    }

    // An array-list datastructure that is synchronized between the GPU and CPU.
    //
    // Its basically an std::vector that is backed by a GPU buffer. It keeps track
    // of which items in the std::vector have changed and then updates the GPU buffer
    // accordingly. It can be bound just like a GPU buffer with the .bind() function.
    //
    // The synchronization is done in a lazy fashion - the underlying GPU buffer is
    // only updated once .bind() is called. Until then, all changes to the list are
    // only visible on the CPU.
    //
    // The way this works is that we store a separate flag for each item in the
    // std::vector that tells us whether that particular item has changed since the
    // last call to .bind(). Then, when .bind() is called, we loop through all of
    // the items, and update all the items that have been flagged as "dirty".
    template <class T> struct GpuSyncedList {

        // Initialize a GPU sync list with the given initial capacity.
        void create(size_t initialCapacity) {
            items.reserve(initialCapacity);
            dirtyBits.reserve(initialCapacity);
            gpuBuffer = thing->createGpuBuffer(NULL, items.capacity() * sizeof(T));
            gpuBufferCapacity = items.capacity();
        }

        // destroy the sync list and free all of it's memory.
        void destroy() {
            thing->destroyGpuBuffer(gpuBuffer);
            gpuBufferCapacity = 0;
        }

        // Push an item to the end of the GPU sync list.
        void push(T item) {
            items.push_back(item);
            dirtyBits.push_back(true);
        }

        // Pop the last item off of the GPU sync list.
        T pop() {
            assert(items.size() > 0);
            T item = items.back();
            items.pop_back();
            dirtyBits.pop_back();
            return item;
        }

        // Return number of items in the sync list.
        size_t length() {
            return items.size();
        }

        // Remove an item from the specified index.
        void remove(size_t index) {
            assert(index >= 0 && index < items.size());
            items.erase(items.begin() + (int)index);
            dirtyBits.pop_back();
            // The last part of the array was shifted by 1 element so we have to mark that whole region.
            for (size_t i = index; i < items.size(); ++i) {
                dirtyBits[i] = true;
            }
        }

        // Bind the GPU sync list to a GPU buffer slot.
        void bind(BufferSlot slot, int binding) {
            if (gpuBufferCapacity < items.capacity()) {
                // Capacity changed, so we have to reallocate the buffer on the GPU.
                thing->recreateGpuBuffer(gpuBuffer, NULL, items.capacity() * sizeof(T));
                thing->updateGpuBuffer(gpuBuffer, 0, items.data(), items.size() * sizeof(T));
                gpuBufferCapacity = items.capacity();
                dirtyBits.clear();
                dirtyBits.resize(items.size(), false);
            }
            else {
                // Update only the items that were marked as "dirty".
                // We dont update each item individually, but rather we update sequences of dirty items.
                // So for example if we had 8 items, and consecutive dirty items (marked as "D") like this:
                //
                // _ D D D _ _ D D
                //
                // We would update them in a batch like this:
                //
                // _[D D D]_ _[D D]
                //
                // This can save a few GPU transfer operations compared to doing each item individually.
                int startIdx = -1;
                for (size_t i = 0; i <= items.size(); ++i) { // this loop goes 1 past the end of the items
                    bool dirty = i < items.size() ? dirtyBits[i] : false;
                    if (dirty && startIdx < 0) {
                        // record start of a range
                        startIdx = (int)i;
                    }
                    else if (!dirty && startIdx >= 0) {
                        // found the end of the range - update it
                        size_t start = (size_t)startIdx;
                        size_t size = i - start;
                        thing->updateGpuBuffer(gpuBuffer, start * sizeof(T), &items[start], size * sizeof(T));
                        for (size_t j = 0; j < size; ++j) {
                            dirtyBits[start + j] = false;
                        }
                    }
                }
            }

            //
            // ----- Everything is synchronized beyond this point -----
            //

            if (items.size() > 0) {
                // Apparently its an error to bind an empty range so we need to check for that..
                thing->bindGpuBuffer(gpuBuffer, slot, binding, 0, items.size() * sizeof(T));
            }
        }

        // We want to control when each item is modified so we can mark it as "dirty",
        // but we still want to have nice and intuitive array access to the items. So we
        // wrap each item from the list into this special struct which can be implicitly
        // converted to the item type, and can be assigned to.
        struct Wrapper {
            GpuSyncedList* list;
            size_t index;
            operator T() {
                return list->items[index];
            }
            Wrapper& operator =(T item) {
                // This is the whole point of this Wrapper, we can detect when the items are over-written.
                list->items[index] = item;
                list->dirtyBits[index] = true;
                return *this;
            }
        };

        // Returns a wrapper to the item at the requested index.
        Wrapper operator [](size_t index) {
            assert(index < items.size());
            Wrapper w;
            w.list = this;
            w.index = index;
            return w;
        }

        GpuBuffer gpuBuffer;
        size_t gpuBufferCapacity;
        std::vector<T> items;
        std::vector<bool> dirtyBits;
        MainView* thing;
    };


struct Ray {
    vec3 pos;
    vec3 dir;
};

struct Light {
    alignas(sizeof(vec4)) vec3 pos;
    alignas(sizeof(vec4)) vec3 color;
};

struct Material {
    alignas(sizeof(vec4)) vec4 color;
    float reflectance;
    float ior;
    int textureIndex;
};

struct Plane {
    alignas(sizeof(vec4)) vec3 normal;
    alignas(sizeof(vec4)) vec3 pos;
    uint material;
};

struct Sphere {
    alignas(sizeof(vec4)) vec3 pos;
    float radius;
    uint material;
};

struct Voxel {
    alignas(sizeof(vec4)) ivec3 pos;
    uint material;
};

struct Portal {
    alignas(sizeof(vec4)) vec3 pos;
    alignas(sizeof(vec4)) vec3 normal;
    float radius;
};

double cursorX, cursorY;

Shader raytraceShader;
Shader paintShader;
GpuBuffer fullscreenQuad;
TextureArray textureAtlas;
GpuSyncedList<Light> lights;
GpuSyncedList<Material> materials;
GpuSyncedList<Plane> planes;
GpuSyncedList<Sphere> spheres;
GpuSyncedList<Voxel> voxels;
GpuSyncedList<Portal> portals;
uint raytraceOutputFramebuffer;
uint fullscreenQuadVAO;
Texture raytraceOutputTexture;

static constexpr float jumpVelocity = 10;
static constexpr float gravity = 40.0f;
static constexpr float playerHeight = 0.9f;
static constexpr float floatMax = 3.402823466e+38;
static constexpr float rayEpsilon = 0.001f;
static constexpr float PI = 3.141592741f;

vec3 cameraPos = vec3(0, 10, 0);
vec3 cameraDir = vec3(0, 0, -1);
vec3 cameraUp = vec3(0, 1, 0);
vec3 cameraRight = normalize(cross(cameraDir, cameraUp));
float cameraFoveaDist = 1.5f;
float cameraPitch;
float cameraYaw;
float velocityY = 0;
bool doubleJumpReady = true;
GameMode gameMode = PlayMode;
uint material = 2;
Light lightBuffer[100];

mat3 getPortalMatrix(Portal portal);
float intersect(Ray r, Plane p);
float intersect(Ray r, Sphere s);
float intersect(Ray r, Voxel v);
float intersect(Ray r, Portal p);
Ray trace(Ray ray);
int getClosestPortal(vec3 pos);
void printPickedMaterial();
float getDistanceToNearestObject(vec3 from, vec3 dir);
vec3 moveWithCollisionCheck(vec3 from, vec3 dir, float epsilon = rayEpsilon);
void loadScene();

void gameOnKey(int key, int scancode, int action, int mods);
void gameOnMouseMove(double newX, double newY);
void gameOnMouseButton(int button, int action, int mods);
void gameOnMouseWheel(double dX, double dY);
void gameOnInit();
void gameOnUpdate(double dt);
};

    #endif // MAINVIEW_H
