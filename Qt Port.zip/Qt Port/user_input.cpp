#include "mainview.h"

#include <QDebug>

// Triggered by pressing a key
void MainView::keyPressEvent(QKeyEvent *ev)
{
    switch(ev->key()) {
    case 'W':
        wIsDown = true;
        break;
    case 'A':
        aIsDown = true;
        break;
    case 'S':
        sIsDown = true;
        break;
    case 'D':
        dIsDown = true;
        break;
    case Qt::Key_Space:
        spaceIsDown = true;
        break;
    case Qt::Key_Control:
        ctrlIsDown = true;
        break;
    case Qt::Key_Shift:
        shiftIsDown = true;
        break;
    case Qt::Key_Escape:
        exit(0);
    default:
        break;
    }

    gameOnKey(ev->key(), 0, 1, 0);
}

// Triggered by releasing a key
void MainView::keyReleaseEvent(QKeyEvent *ev)
{
    switch(ev->key()) {
    case 'W':
        wIsDown = false;
        break;
    case 'A':
        aIsDown = false;
        break;
    case 'S':
        sIsDown = false;
        break;
    case 'D':
        dIsDown = false;
        break;
    case Qt::Key_Space:
        spaceIsDown = false;
        break;
    case Qt::Key_Control:
        ctrlIsDown = false;
        break;
    case Qt::Key_Shift:
        shiftIsDown = false;
        break;
    default:
        return;
    }
}

// Triggered by clicking two subsequent times on any mouse button
// It also fires two mousePress and mouseRelease events!
void MainView::mouseDoubleClickEvent(QMouseEvent *ev)
{}

// Triggered when moving the mouse inside the window (only when the mouse is clicked!)
void MainView::mouseMoveEvent(QMouseEvent *ev)
{
    // set cursor position to center of screen
    QPoint p = mapToGlobal({ 0, 0 });
    QCursor::setPos(p.x() + width() / 2, p.y() + height() / 2);

    gameOnMouseMove(ev->x(), ev->y());
}

// Triggered when pressing any mouse button
void MainView::mousePressEvent(QMouseEvent *ev)
{
    // Do not remove the line below, clicking must focus on this widget!
    this->setFocus();
    gameOnMouseButton(ev->button(), 0, 0);
}

// Triggered when releasing any mouse button
void MainView::mouseReleaseEvent(QMouseEvent *ev)
{
}

// Triggered when clicking scrolling with the scroll wheel on the mouse
void MainView::wheelEvent(QWheelEvent *ev)
{
    gameOnMouseWheel(0,ev->delta());
}
// Triggered when mouse leaves the window
void MainView::leaveEvent(QEvent *ev){
    QPoint pos = QCursor::pos();
    QPoint p = mapToGlobal({ 0, 0 });
    QCursor::setPos(p.x() + width() / 2, p.y() + height() / 2);

    gameOnMouseMove(pos.x(), pos.y());
}

