#include "mainview.h"

#include <QDateTime>
#include <math.h>
#include <QFile>
#include <QOpenGLFramebufferObject>

static double t = 0;

MainView::MainView(QWidget *parent) : QOpenGLWidget(parent) {
    qDebug() << "MainView constructor";

    connect(&timer, SIGNAL(timeout()), this, SLOT(update()));
    timer.start(1000.0 / 60.0);
}

MainView::~MainView() {
    qDebug() << "MainView destructor";
    makeCurrent();
}

// --- OpenGL initialization

void MainView::initializeGL() {
    qDebug() << ":: Initializing OpenGL";
    initializeOpenGLFunctions();

    connect(&debugLogger, SIGNAL( messageLogged( QOpenGLDebugMessage)),
            this, SLOT(onMessageLogged(QOpenGLDebugMessage)), Qt::DirectConnection);

    if (debugLogger.initialize()) {
        qDebug() << ":: Logging initialized";
        debugLogger.startLogging(QOpenGLDebugLogger::SynchronousLogging);
    }

    QString glVersion;
    glVersion = reinterpret_cast<const char*>(glGetString(GL_VERSION));
    qDebug() << ":: Using OpenGL" << qPrintable(glVersion);

    setFocus(); // So that we don't need to click before user input is captured.
    setMouseTracking(true); // So that we ALWAYS track mouse motion - not just when clicked.
    setCursor(QCursor(Qt::BlankCursor)); // Make cursor invisible while in the view.
    gameOnInit();
}

// --- OpenGL drawing

void MainView::paintGL() {

    gameOnUpdate(0);
}

void MainView::resizeGL(int newWidth, int newHeight) {
    glViewport(0, 0, newWidth, newHeight);
}

/**
 * @brief MainView::onMessageLogged
 *
 * OpenGL logging function, do not change
 *
 * @param Message
 */
void MainView::onMessageLogged( QOpenGLDebugMessage Message ) {
    qDebug() << " → Log:" << Message;
}



























char *MainView::readWholeFile(const char *filename) {
    QFile f(filename);
    f.open(QIODevice::ReadOnly | QIODevice::Text);
    QTextStream in(&f);
    QString ree = in.readAll();
    char *str = (char *)malloc(ree.length()+1);
    memcpy(str,ree.toStdString().data(),ree.length());
    str[ree.length()] = 0;
    return str;
}

MainView::GpuBuffer MainView::createGpuBuffer(void *data, size_t size) {
    GpuBuffer buffer;
    glGenBuffers(1, &buffer);
    assert(buffer);

    bindGpuBuffer(buffer, GL_ARRAY_BUFFER, 0);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)size, data, GL_DYNAMIC_DRAW);

    return buffer;
}
void MainView::recreateGpuBuffer(GpuBuffer buffer, const void *data, size_t size) {
    bindGpuBuffer(buffer, GL_ARRAY_BUFFER, 0);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)size, data, GL_DYNAMIC_DRAW);
}
void MainView::updateGpuBuffer(GpuBuffer buffer, size_t offset, const void *data, size_t size) {
    bindGpuBuffer(buffer, GL_ARRAY_BUFFER, 0);
    GLint bufferSize;
    glGetBufferParameteriv(GL_ARRAY_BUFFER, GL_BUFFER_SIZE, &bufferSize);
    assert(offset + size <= (size_t)bufferSize);
    glBufferSubData(GL_ARRAY_BUFFER, (GLintptr)offset, (GLsizeiptr)size, data);
}
void MainView::bindGpuBuffer(GpuBuffer buffer, BufferSlot slot, int binding) {
    switch (slot) {
        case GL_SHADER_STORAGE_BUFFER:
        case GL_UNIFORM_BUFFER:
        case GL_ATOMIC_COUNTER_BUFFER:
        case GL_TRANSFORM_FEEDBACK_BUFFER:
            // glBindBufferBase only makes sense for the buffer types above.
            glBindBufferBase((GLenum)slot, (GLuint)binding, buffer);
            break;
        default:
            // glBindBuffer is for all other buffer types.
            glBindBuffer((GLenum)slot, buffer);
            break;
    }
}
void MainView::bindGpuBuffer(GpuBuffer buffer, BufferSlot slot, int binding, size_t offset, size_t size) {
    assert(slot == GL_SHADER_STORAGE_BUFFER || slot == GL_UNIFORM_BUFFER || slot == GL_ATOMIC_COUNTER_BUFFER || slot == GL_TRANSFORM_FEEDBACK_BUFFER);
    glBindBufferRange((GLenum)slot, (GLuint)binding, buffer, (GLintptr)offset, (GLsizeiptr)size);

}
void MainView::destroyGpuBuffer(GpuBuffer buffer) {
    glDeleteBuffers(1, &buffer);

}

MainView::Texture MainView::createTexture(const void *pixels, uint width, uint height, TextureStoreFormat internalFormat) {
    Texture tex;
    glGenTextures(1, &tex);
    assert(tex);

    bindTexture(tex, 0);

    // Bilinear filtering and clamp to edges by default.
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    glTexImage2D(
        GL_TEXTURE_2D,		   // Target texture type
        0,					   // Mipmap level - ALWAYS 0
        (GLint)internalFormat, // Internal format
        (GLsizei)width,	       // Image width
        (GLsizei)height,       // Image height
        0,				       // Border? - always 0 aparently.
        GL_RGBA,		       // Color components - important not to mess up
        GL_UNSIGNED_BYTE,      // Component format
        pixels                 // Image data
    );


    return tex;
}
MainView::Texture MainView::loadTexture(const char *filename, TextureStoreFormat internalFormat) {
    QImage image = QImage(filename);
    QVector<quint8> pixels = imageToBytes(image);
    Texture tex = createTexture(pixels.data(), (uint)image.width(), (uint)image.height(), internalFormat);
    assert(tex);
    return tex;
}
void MainView::bindTexture(Texture tex, uint unit) {
    assert(unit < 80);
    glActiveTexture(GL_TEXTURE0 + unit);
    glBindTexture(GL_TEXTURE_2D, tex);

}
void MainView::destroyTexture(Texture tex) {
    glDeleteTextures(1, &tex);

}

MainView::TextureArray MainView::loadTextureArray(const char* filenames[], uint numFilenames, TextureStoreFormat internalFormat) {
    QImage image = QImage(filenames[0]);
    QVector<quint8> pixels = imageToBytes(image);
    TextureArray tex;
    glGenTextures(1, &tex);
    assert(tex);

    // First allocate the full storage for the texture array.
    bindTextureArray(tex, 0);
    glTexStorage3D(GL_TEXTURE_2D_ARRAY, 1, (GLenum)internalFormat, image.width(), image.height(), (GLsizei)numFilenames);

    // Then read and copy the pixels over for each texture in the array.
    glTexSubImage3D(GL_TEXTURE_2D_ARRAY, 0, 0, 0, 0, image.width(), image.height(), 1, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
    for (uint i = 1; i < numFilenames; ++i) {
        image = QImage(filenames[i]);
        pixels = imageToBytes(image);
        glTexSubImage3D(GL_TEXTURE_2D_ARRAY, 0, 0, 0, (GLint)i, image.width(), image.height(), 1, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
    }

    // Bilinear filtering and repeat wrapping by default.
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_REPEAT);


    return tex;
}
void MainView::bindTextureArray(TextureArray tex, uint unit) {
    assert(unit < 80);
    glActiveTexture(GL_TEXTURE0 + unit);
    glBindTexture(GL_TEXTURE_2D_ARRAY, tex);

}
void MainView::destroyTextureArray(TextureArray tex) {
    glDeleteTextures(1, &tex);

}

// Return the size in bytes needed for a shader uniform of a given type.
static size_t sizeofShaderDataType(MainView::ShaderDataType type) {
    switch (type) {
        case GL_FLOAT:             return sizeof(float[1]);
        case GL_FLOAT_VEC2:        return sizeof(float[2]);
        case GL_FLOAT_VEC3:        return sizeof(float[3]);
        case GL_FLOAT_VEC4:        return sizeof(float[4]);
        case GL_FLOAT_MAT2:        return sizeof(float[2*2]);
        case GL_FLOAT_MAT3:        return sizeof(float[3*3]);
        case GL_FLOAT_MAT4:        return sizeof(float[4*4]);
        case GL_INT:               return sizeof(int[1]);
        case GL_INT_VEC2:          return sizeof(int[2]);
        case GL_INT_VEC3:          return sizeof(int[3]);
        case GL_INT_VEC4:          return sizeof(int[4]);
        case GL_UNSIGNED_INT:      return sizeof(uint[1]);
        case GL_UNSIGNED_INT_VEC2: return sizeof(uint[2]);
        case GL_UNSIGNED_INT_VEC3: return sizeof(uint[3]);
        case GL_UNSIGNED_INT_VEC4: return sizeof(uint[4]);
        case GL_SAMPLER_2D:
        case GL_SAMPLER_2D_ARRAY:
            return sizeof(int);
        default: assert(0); return 0;
    }
}

MainView::Shader MainView::loadShader(const char *vertFile, const char *fragFile) {
    Shader program = glCreateProgram();
    assert(program);

    auto something = [this](Shader program, const char* vertFile, const char* fragFile)
    {   
        char *vertSrc = readWholeFile(vertFile);
        char *fragSrc = readWholeFile(fragFile);
        assert(vertSrc);
        assert(fragSrc);

        GLuint vert = glCreateShader(GL_VERTEX_SHADER);
        GLuint frag = glCreateShader(GL_FRAGMENT_SHADER);
        assert(vert);
        assert(frag);

        glShaderSource(vert, 1, &vertSrc, NULL);
        glCompileShader(vert);
        GLint vertOk;
        glGetShaderiv(vert, GL_COMPILE_STATUS, &vertOk);
        if (!vertOk) {
        #ifndef NDEBUG
            GLint logLength;
            glGetShaderiv(vert, GL_INFO_LOG_LENGTH, &logLength);
            char *log = (char *)malloc((size_t)logLength);
            glGetShaderInfoLog(vert, logLength, NULL, (GLchar *)log);
            free(log);
            printf("GLSL vertex shader: %s\n", log);
        #endif
            glDeleteShader(vert);
            glDeleteShader(frag);
            return false;
        }

        glShaderSource(frag, 1, &fragSrc, NULL);
        glCompileShader(frag);
        GLint fragOk;
        glGetShaderiv(frag, GL_COMPILE_STATUS, &fragOk);
        if (!vertOk) {
        #ifndef NDEBUG
            GLint logLength;
            glGetShaderiv(vert, GL_INFO_LOG_LENGTH, &logLength);
            char *log = (char *)malloc((size_t)logLength);
            glGetShaderInfoLog(vert, logLength, NULL, (GLchar *)log);
            printf("GLSL vertex shader: %s\n", log);
            free(log);
        #endif
            glDeleteShader(vert);
            glDeleteShader(frag);
            return false;
        }

        glAttachShader(program, vert);
        glAttachShader(program, frag);
        glLinkProgram(program);
        GLint linkOk;
        glGetProgramiv(program, GL_LINK_STATUS, &linkOk);
        if (!linkOk) {
        #ifndef NDEBUG
            GLint logLength;
            glGetProgramiv(program, GL_INFO_LOG_LENGTH, &logLength);
            char *log = (char *)malloc((size_t)logLength);
            glGetProgramInfoLog(program, logLength, NULL, (GLchar *)log);
            printf("GLSL linker: %s\n", log);
            free(log);
        #endif
            glDeleteShader(vert);
            glDeleteShader(frag);
            return false;
        }

        free(vertSrc);
        free(fragSrc);

        glDetachShader(program, vert);
        glDetachShader(program, frag);
        glDeleteShader(vert);
        glDeleteShader(frag);


        return true;
    };

    bool linkOk = something(program, vertFile, fragFile);
    if (!linkOk) {
        glDeleteProgram(program);
        program = 0;
    }
    return program;
}
void MainView::setUniform(Shader s, uint location, ShaderDataType type, const void *value, size_t valueSize) {
    assert(valueSize == sizeofShaderDataType(type));
    bindShader(s);

    switch (type) {
        case GL_FLOAT:				glUniform1fv((GLint)location, 1, (const GLfloat *)value); break;
        case GL_FLOAT_VEC2:			glUniform2fv((GLint)location, 1, (const GLfloat *)value); break;
        case GL_FLOAT_VEC3:			glUniform3fv((GLint)location, 1, (const GLfloat *)value); break;
        case GL_FLOAT_VEC4:			glUniform4fv((GLint)location, 1, (const GLfloat *)value); break;
        case GL_FLOAT_MAT2:			glUniformMatrix2fv((GLint)location, 1, GL_FALSE, (const GLfloat *)value); break;
        case GL_FLOAT_MAT3:			glUniformMatrix3fv((GLint)location, 1, GL_FALSE, (const GLfloat *)value); break;
        case GL_FLOAT_MAT4:			glUniformMatrix4fv((GLint)location, 1, GL_FALSE, (const GLfloat *)value); break;
        case GL_INT:				glUniform1iv((GLint)location, 1, (const GLint *)value); break;
        case GL_INT_VEC2:			glUniform2iv((GLint)location, 1, (const GLint *)value); break;
        case GL_INT_VEC3:			glUniform3iv((GLint)location, 1, (const GLint *)value); break;
        case GL_INT_VEC4:			glUniform4iv((GLint)location, 1, (const GLint *)value); break;
        case GL_UNSIGNED_INT:		glUniform1uiv((GLint)location, 1, (const GLuint *)value); break;
        case GL_UNSIGNED_INT_VEC2:	glUniform2uiv((GLint)location, 1, (const GLuint *)value); break;
        case GL_UNSIGNED_INT_VEC3:	glUniform3uiv((GLint)location, 1, (const GLuint *)value); break;
        case GL_UNSIGNED_INT_VEC4:	glUniform4uiv((GLint)location, 1, (const GLuint *)value); break;
        case GL_BOOL:				glUniform1iv((GLint)location, 1, (const GLint *)value); break;
        case GL_SAMPLER_2D:
        case GL_SAMPLER_2D_ARRAY:
            glUniform1iv((GLint)location, 1, (const GLint *)value); break;
        default: assert(0); break;
    }


}
void MainView::bindShader(Shader s) {
    glUseProgram(s);

}
void MainView::destroyShader(Shader s) {
    glDeleteProgram(s);

}

mat3 MainView::getPortalMatrix(Portal portal) {
    vec3 n = normalize(portal.normal);
    vec3 b = vec3(0, 1, 0);
    if (abs(dot(n, b)) > 0.99) {
        b = vec3(1, 0, 0);
    }
    vec3 t = normalize(cross(n, b));
    b = normalize(cross(t, n));
    return transpose(mat3(t, b, n));
}
float MainView::intersect(Ray r, Plane p) {
    const float epsilon = 0.001;
    float denom = dot(r.dir, p.normal);
    if (abs(denom) > epsilon) {
        float t = dot((p.pos - r.pos), p.normal) / denom;
        if (t > epsilon)
            return t;
    }
    return floatMax;
}
float MainView::intersect(Ray r, Sphere s) {
    float a = 1;
    float b = 2 * dot(r.pos - s.pos, r.dir);
    float c = dot(s.pos, (s.pos - (float)2 * r.pos)) + dot(r.pos, r.pos) - s.radius * s.radius;
    float discriminant = b * b - 4 * a * c;
    if (discriminant < 0)
        return floatMax;
    else
        return (float)-0.5 * (b + sqrt(discriminant));
}
float MainView::intersect(Ray r, Voxel v) {
    const float epsilon = 0.001;
    if (r.dir.x == 0) r.dir.x = epsilon;
    if (r.dir.y == 0) r.dir.y = epsilon;
    if (r.dir.z == 0) r.dir.z = epsilon;
    vec3 invDir = 1.0f / r.dir;
    vec3 ld = (vec3(v.pos) - r.pos) * invDir;
    vec3 rd = (vec3(v.pos) - r.pos) * invDir + invDir;
    vec3 mind = min(ld, rd);
    vec3 maxd = max(ld, rd);
    float dmin = max(max(mind.x, mind.y), mind.z);
    float dmax = min(min(maxd.x, maxd.y), maxd.z);
    if (dmin > dmax)
        return floatMax;
    else
        return dmin;
}
float MainView::intersect(Ray r, Portal p) {
    const float epsilon = 0.001;
    float denom = dot(r.dir, p.normal);
    if (abs(denom) > epsilon) {
        float t = dot((p.pos - r.pos), p.normal) / denom;
        if (t > epsilon) {
            vec3 v = r.pos + r.dir * t - p.pos;
            float d2 = dot(v, v);
            if (d2 <= p.radius * p.radius)
                return t;
        }
    }
    return floatMax;
}
MainView::Ray MainView::trace(Ray ray) {
    vec3 hitNormal;
    float hitDist = floatMax;

    for (uint i = 0; i < planes.length(); ++i) {
        Plane plane = planes[i];
        float d = intersect(ray, plane);
        if (d > 0 && d < hitDist) {
            hitDist = d;
            hitNormal = plane.normal;
        }
    }

    for (uint i = 0; i < spheres.length(); ++i) {
        Sphere sphere = spheres[i];
        float d = intersect(ray, sphere);
        if (d > 0 && d < hitDist) {
            hitDist = d;
            hitNormal = normalize(ray.pos + ray.dir * d - sphere.pos);
        }
    }

    for (uint i = 0; i < voxels.length(); ++i) {
        Voxel voxel = voxels[i];
        float d = intersect(ray, voxel);
        if (d > 0 && d < hitDist) {
            hitDist = d;
            vec3 hitPos = ray.pos + ray.dir * hitDist;
            hitNormal = normalize(vec3(ivec3(2.0001f * (hitPos - vec3(voxel.pos) - 0.5f))));
        }
    }

    ray.pos += ray.dir * hitDist;
    ray.dir = hitNormal;
    return ray;
}
int MainView::getClosestPortal(vec3 pos) {
    Portal P1 = portals[0];
    Portal P2 = portals[1];
    if (distance(P1.pos, pos) < distance(P2.pos, pos))
        return 0;
    else
        return 1;
}
void MainView::printPickedMaterial() {
    switch (material) {
        case 1:  printf("selected Cyan\n"); break;
        case 2:	 printf("selected Dirt\n"); break;
        case 3:	 printf("selected Dark Wood\n"); break;
        case 4:	 printf("selected Wood\n"); break;
        case 5:	 printf("selected Stone\n"); break;
        case 6:	 printf("selected Chisled Stone\n"); break;
        case 7:	 printf("selected Bricks\n"); break;
        case 8:	 printf("selected Quartz\n"); break;
        case 9:	 printf("selected Purple\n"); break;
        case 10: printf("selected Candy\n"); break;
        default: printf("selected material %d\n", (int)material); break;
    }
}
float MainView::getDistanceToNearestObject(vec3 from, vec3 dir) {
    Ray r0 = { from, normalize(dir) };
    Ray r1 = trace(r0);
    return distance(r0.pos, r1.pos);
}
vec3 MainView::moveWithCollisionCheck(vec3 from, vec3 dir, float epsilon) {
    float dist = length(dir);
    dir = normalize(dir);
    Ray movementRay = { from, dir };
    Ray movementRayEnd = trace(movementRay);
    float maxDist = max(0.0f, distance(movementRayEnd.pos, movementRay.pos) - epsilon);
    return from + min(dist, maxDist) * dir;
}
void MainView::loadScene() {
    lights.create(24);
    lights.push({ { -1.81297, 5.7906, -4.21272 }, { 0.579913, 1.69076, 0.00375378 } });
    lights.push({ { -4.36842, 5.08229, -9.05002 }, { 1.43962, 1.75503, 2.42622 } });
    lights.push({ { 2.10183, 7.69307, -9.4391 }, { 2.46852, 2.68789, 1.05087 } });
    lights.push({ { 7.10277, 7.28197, -6.67717 }, { 2.57683, 0.522324, 2.23981 } });
    lights.push({ { 8.96205, 5.83229, 4.55122 }, { 0.911985, 1.5406, 2.1315 } });
    lights.push({ { 11.2218, 6.36449, 8.88403 }, { 1.09336, 0.274209, 0.0449538 } });
    lights.push({ { 7.63116, 8.77453, 9.26327 }, { 2.96558, 0.497696, 0.441939 } });
    lights.push({ { -0.356331, 6.98776, 5.23919 }, { 0.014008, 0.35725, 1.33708 } });
    lights.push({ { 0.0614676, 6.0846, 5.48466 }, { 1.59499, 1.13364, 0.0267342 } });
    lights.push({ { -6.23985, 5.89135, 6.44163 }, { 1.8215, 1.80529, 1.71355 } });
    lights.push({ { -10.1994, 6.52015, 9.18334 }, { 1.35237, 1.98914, 0.498703 } });
    lights.push({ { -15.5818, 4.15572, 11.3748 }, { 1.82305, 0.171117, 1.05637 } });
    lights.push({ { -18.3772, 8.64235, 9.35531 }, { 1.55965, 2.40782, 2.34996 } });
    lights.push({ { -16.2988, 9.69448, 5.41378 }, { 2.18003, 2.62792, 0.90585 } });
    lights.push({ { -17.5426, 8.04461, 0.952491 }, { 1.61806, 2.77715, 2.8677 } });
    lights.push({ { -18.897, 6.62192, -2.58986 }, { 0.705985, 1.38624, 0.427015 } });
    lights.push({ { -23.3005, 7.29912, -0.549724 }, { 2.33897, 0.628803, 2.58672 } });
    lights.push({ { -36.7211, 8.86283, -3.16538 }, { 2.99908, 2.99039, 2.53096 } });
    lights.push({ { -30.832, 5.55614, -7.45064 }, { 0.798639, 1.17731, 1.8345 } });
    lights.push({ { 9.27975, 9.88058, -11.054 }, { 0.0712302, 2.52043, 0.891842 } });
    lights.push({ { 7.80433, 6.77498, -4.62547 }, { 2.03162, 0.277871, 1.1276 } });
    lights.push({ { -4.00477, 2.49793, -2.55 }, { 2.75637, 0.026368, 0.168645 } });
    lights.push({ { -4.36956, 2.6189, 3.97399 }, { 1.76373, 0.818689, 0.827662 } });
    lights.push({ { -12.9949, 5.94974, -8.08428 }, { 2.17948, 2.51283, 2.07355 } });
    materials.create(12);
    materials.push({ { 0, 0, 0, 1 }, 0.00f, 1, -1 });
    materials.push({ { 0, 1, 1, 1 }, 0.20f, 1, -1 }); // CYAN
    materials.push({ { 1, 1, 1, 1 }, 0.00f, 1, 0 });  // DIRT
    materials.push({ { 1, 1, 1, 1 }, 0.05f, 1, 1 });  // WOOD DARK
    materials.push({ { 1, 1, 1, 1 }, 0.05f, 1, 2 });  // WOOD
    materials.push({ { 1, 1, 1, 1 }, 0.05f, 1, 3 });  // STONE
    materials.push({ { 1, 1, 1, 1 }, 0.10f, 1, 4 });  // CHISLED STONE
    materials.push({ { 1, 1, 1, 1 }, 0.05f, 1, 5 });  // BRICKS
    materials.push({ { 1, 1, 1, 1 }, 0.25f, 1, 6 });  // QUARTZ
    materials.push({ { 1, 1, 1, 1 }, 0.20f, 1, 7 });  // PURPLE
    materials.push({ { 1, 1, 1, 1 }, 0.30f, 1, 8 });  // CANDY
    materials.push({ { 0.5f, 0.2f, 0.1f, 1 }, 0.4f, 1, -1 });
    materials.push({ { 0.2f, 0.2f, 0.8f, 1 }, 0.3f, 1, -1 });
    planes.create(1);
    planes.push({ { 0, 1, 0 }, { 0, 0, 0 }, 1 });
    spheres.create(3);
    spheres.push({ { -0.5, 0.1, -3 }, 0.5, 12 });
    spheres.push({ { 0.5, 0.5, -4 }, 0.7, 11 });
    spheres.push({ { 0.1, 0.3, -2 }, 0.3, 10 });
    voxels.create(247);
    voxels.push({ { -132, 0, 71 }, 7 });
    voxels.push({ { -4, 0, -3 }, 2 });
    voxels.push({ { -5, 0, -3 }, 2 });
    voxels.push({ { -6, 0, -3 }, 2 });
    voxels.push({ { -4, 0, -4 }, 2 });
    voxels.push({ { -5, 0, -4 }, 2 });
    voxels.push({ { -6, 0, -4 }, 2 });
    voxels.push({ { -4, 0, -5 }, 2 });
    voxels.push({ { -5, 0, -5 }, 2 });
    voxels.push({ { -6, 0, -5 }, 2 });
    voxels.push({ { -5, 1, -6 }, 4 });
    voxels.push({ { -5, 3, -7 }, 4 });
    voxels.push({ { -5, 2, -6 }, 4 });
    voxels.push({ { -4, 1, -6 }, 4 });
    voxels.push({ { -4, 2, -6 }, 4 });
    voxels.push({ { -6, 1, -6 }, 4 });
    voxels.push({ { -6, 2, -6 }, 4 });
    voxels.push({ { -6, 3, -7 }, 4 });
    voxels.push({ { -4, 3, -7 }, 4 });
    voxels.push({ { -7, 3, -7 }, 4 });
    voxels.push({ { -7, 0, -6 }, 4 });
    voxels.push({ { -7, 1, -6 }, 4 });
    voxels.push({ { -7, 2, -6 }, 4 });
    voxels.push({ { -12, 0, -8 }, 6 });
    voxels.push({ { -12, 1, -8 }, 6 });
    voxels.push({ { -12, 4, -8 }, 6 });
    voxels.push({ { -12, 3, -8 }, 6 });
    voxels.push({ { -12, 2, -8 }, 6 });
    voxels.push({ { -13, 4, -9 }, 7 });
    voxels.push({ { -13, 4, -8 }, 7 });
    voxels.push({ { -14, 4, -9 }, 7 });
    voxels.push({ { -14, 4, -8 }, 7 });
    voxels.push({ { -19, 4, -9 }, 7 });
    voxels.push({ { -19, 4, -8 }, 7 });
    voxels.push({ { -20, 4, -9 }, 6 });
    voxels.push({ { -20, 4, -8 }, 6 });
    voxels.push({ { -20, 3, -9 }, 6 });
    voxels.push({ { -20, 3, -8 }, 6 });
    voxels.push({ { -21, 2, -9 }, 6 });
    voxels.push({ { -19, 5, 9 }, 9 });
    voxels.push({ { -17, 6, 5 }, 9 });
    voxels.push({ { -17, 5, 0 }, 9 });
    voxels.push({ { -17, 5, 1 }, 9 });
    voxels.push({ { -18, 5, 0 }, 9 });
    voxels.push({ { -18, 5, 1 }, 9 });
    voxels.push({ { -20, 4, -3 }, 9 });
    voxels.push({ { -13, 1, 12 }, 3 });
    voxels.push({ { -12, 1, 12 }, 3 });
    voxels.push({ { -12, 0, 13 }, 3 });
    voxels.push({ { -13, 0, 13 }, 3 });
    voxels.push({ { -13, 1, 13 }, 3 });
    voxels.push({ { -12, 1, 13 }, 3 });
    voxels.push({ { -12, 2, 11 }, 3 });
    voxels.push({ { -13, 2, 11 }, 3 });
    voxels.push({ { -12, 3, 10 }, 3 });
    voxels.push({ { -13, 3, 10 }, 3 });
    voxels.push({ { -12, 3, 11 }, 3 });
    voxels.push({ { -13, 3, 11 }, 3 });
    voxels.push({ { -13, 3, 9 }, 4 });
    voxels.push({ { -12, 3, 9 }, 4 });
    voxels.push({ { -12, 3, 8 }, 4 });
    voxels.push({ { -13, 3, 7 }, 4 });
    voxels.push({ { -11, 3, 6 }, 4 });
    voxels.push({ { -11, 3, 5 }, 4 });
    voxels.push({ { -10, 3, 5 }, 4 });
    voxels.push({ { -9, 3, 6 }, 4 });
    voxels.push({ { -8, 3, 6 }, 4 });
    voxels.push({ { -8, 3, 5 }, 4 });
    voxels.push({ { -7, 3, 6 }, 4 });
    voxels.push({ { -6, 3, 6 }, 3 });
    voxels.push({ { -5, 0, 6 }, 3 });
    voxels.push({ { -5, 1, 6 }, 3 });
    voxels.push({ { -5, 2, 6 }, 3 });
    voxels.push({ { -5, 3, 6 }, 3 });
    voxels.push({ { -4, 3, 6 }, 3 });
    voxels.push({ { -3, 3, 6 }, 3 });
    voxels.push({ { -2, 3, 6 }, 3 });
    voxels.push({ { -1, 3, 6 }, 3 });
    voxels.push({ { 0, 3, 6 }, 3 });
    voxels.push({ { 1, 3, 6 }, 7 });
    voxels.push({ { 1, 3, 7 }, 7 });
    voxels.push({ { 1, 3, 5 }, 7 });
    voxels.push({ { 2, 4, 7 }, 7 });
    voxels.push({ { 2, 4, 5 }, 7 });
    voxels.push({ { 2, 4, 6 }, 6 });
    voxels.push({ { 2, 5, 5 }, 6 });
    voxels.push({ { 2, 5, 6 }, 6 });
    voxels.push({ { 2, 5, 7 }, 6 });
    voxels.push({ { 2, 6, 6 }, 6 });
    voxels.push({ { -24, 4, -1 }, 8 });
    voxels.push({ { -29, 5, -5 }, 8 });
    voxels.push({ { -35, 5, 0 }, 8 });
    voxels.push({ { -40, 6, -5 }, 9 });
    voxels.push({ { -40, 6, -6 }, 9 });
    voxels.push({ { -40, 6, -4 }, 9 });
    voxels.push({ { -41, 7, -4 }, 9 });
    voxels.push({ { -41, 7, -5 }, 9 });
    voxels.push({ { -41, 7, -6 }, 9 });
    voxels.push({ { -41, 8, -5 }, 9 });
    voxels.push({ { -41, 8, -6 }, 6 });
    voxels.push({ { -41, 8, -4 }, 6 });
    voxels.push({ { -6, 3, -8 }, 4 });
    voxels.push({ { -5, 3, -8 }, 4 });
    voxels.push({ { -4, 3, -8 }, 4 });
    voxels.push({ { -6, 3, -9 }, 4 });
    voxels.push({ { -5, 3, -9 }, 4 });
    voxels.push({ { -4, 3, -9 }, 4 });
    voxels.push({ { -6, 3, -10 }, 4 });
    voxels.push({ { -5, 3, -10 }, 4 });
    voxels.push({ { -4, 3, -10 }, 4 });
    voxels.push({ { -3, 3, -7 }, 4 });
    voxels.push({ { -3, 3, -8 }, 4 });
    voxels.push({ { -3, 3, -9 }, 4 });
    voxels.push({ { -3, 3, -10 }, 4 });
    voxels.push({ { -2, 3, -7 }, 4 });
    voxels.push({ { -2, 3, -8 }, 4 });
    voxels.push({ { -2, 3, -9 }, 4 });
    voxels.push({ { -2, 3, -10 }, 4 });
    voxels.push({ { -1, 3, -7 }, 4 });
    voxels.push({ { -1, 3, -8 }, 4 });
    voxels.push({ { -1, 3, -9 }, 4 });
    voxels.push({ { -1, 3, -10 }, 4 });
    voxels.push({ { -6, 3, -11 }, 4 });
    voxels.push({ { -5, 3, -11 }, 4 });
    voxels.push({ { -4, 3, -11 }, 4 });
    voxels.push({ { -3, 3, -11 }, 4 });
    voxels.push({ { -2, 3, -11 }, 4 });
    voxels.push({ { -1, 3, -11 }, 4 });
    voxels.push({ { 0, 3, -7 }, 7 });
    voxels.push({ { 0, 3, -9 }, 7 });
    voxels.push({ { 0, 3, -8 }, 7 });
    voxels.push({ { 0, 3, -10 }, 7 });
    voxels.push({ { 0, 3, -11 }, 7 });
    voxels.push({ { -1, 3, -12 }, 7 });
    voxels.push({ { -5, 3, -12 }, 7 });
    voxels.push({ { -4, 3, -12 }, 7 });
    voxels.push({ { -3, 3, -12 }, 7 });
    voxels.push({ { -2, 3, -12 }, 7 });
    voxels.push({ { 0, 3, -12 }, 7 });
    voxels.push({ { -6, 3, -12 }, 7 });
    voxels.push({ { 1, 4, -7 }, 9 });
    voxels.push({ { 1, 4, -8 }, 9 });
    voxels.push({ { 1, 4, -9 }, 9 });
    voxels.push({ { 1, 4, -10 }, 9 });
    voxels.push({ { 1, 4, -11 }, 9 });
    voxels.push({ { 1, 4, -12 }, 9 });
    voxels.push({ { 2, 4, -12 }, 9 });
    voxels.push({ { 2, 4, -11 }, 9 });
    voxels.push({ { 2, 4, -10 }, 9 });
    voxels.push({ { 2, 4, -9 }, 9 });
    voxels.push({ { 3, 4, -7 }, 3 });
    voxels.push({ { 3, 4, -9 }, 3 });
    voxels.push({ { 3, 4, -11 }, 3 });
    voxels.push({ { 3, 4, -12 }, 3 });
    voxels.push({ { 3, 4, -10 }, 3 });
    voxels.push({ { 3, 4, -8 }, 3 });
    voxels.push({ { 4, 4, -12 }, 3 });
    voxels.push({ { 4, 4, -11 }, 3 });
    voxels.push({ { 4, 4, -10 }, 3 });
    voxels.push({ { 4, 4, -9 }, 3 });
    voxels.push({ { 4, 4, -8 }, 3 });
    voxels.push({ { 4, 4, -7 }, 3 });
    voxels.push({ { 5, 4, -12 }, 3 });
    voxels.push({ { 5, 4, -10 }, 3 });
    voxels.push({ { 5, 4, -9 }, 3 });
    voxels.push({ { 5, 4, -8 }, 3 });
    voxels.push({ { 5, 4, -7 }, 3 });
    voxels.push({ { 5, 4, -11 }, 3 });
    voxels.push({ { 6, 4, -12 }, 3 });
    voxels.push({ { 6, 4, -11 }, 3 });
    voxels.push({ { 6, 4, -10 }, 3 });
    voxels.push({ { 6, 4, -9 }, 3 });
    voxels.push({ { 6, 4, -8 }, 3 });
    voxels.push({ { 6, 4, -7 }, 3 });
    voxels.push({ { 7, 4, -10 }, 3 });
    voxels.push({ { 7, 4, -9 }, 3 });
    voxels.push({ { 7, 4, -8 }, 3 });
    voxels.push({ { 7, 4, -7 }, 3 });
    voxels.push({ { 6, 4, -6 }, 3 });
    voxels.push({ { 7, 4, -6 }, 3 });
    voxels.push({ { 8, 4, -8 }, 3 });
    voxels.push({ { 8, 4, -7 }, 3 });
    voxels.push({ { 8, 4, -6 }, 3 });
    voxels.push({ { 9, 4, -8 }, 3 });
    voxels.push({ { 9, 4, -7 }, 3 });
    voxels.push({ { 6, 4, -5 }, 3 });
    voxels.push({ { 7, 4, -5 }, 3 });
    voxels.push({ { 8, 4, -5 }, 3 });
    voxels.push({ { 9, 4, -6 }, 3 });
    voxels.push({ { 9, 4, -5 }, 3 });
    voxels.push({ { 7, 2, -4 }, 2 });
    voxels.push({ { 7, 3, -4 }, 2 });
    voxels.push({ { 8, 3, -4 }, 2 });
    voxels.push({ { 8, 2, -4 }, 2 });
    voxels.push({ { 7, 4, -4 }, 2 });
    voxels.push({ { 8, 4, -4 }, 2 });
    voxels.push({ { 6, 4, -4 }, 2 });
    voxels.push({ { 9, 4, -4 }, 2 });
    voxels.push({ { 8, 3, 7 }, 10 });
    voxels.push({ { 9, 3, 7 }, 10 });
    voxels.push({ { 8, 3, 6 }, 10 });
    voxels.push({ { 7, 3, 7 }, 10 });
    voxels.push({ { 8, 3, 8 }, 10 });
    voxels.push({ { 8, 3, 5 }, 10 });
    voxels.push({ { 10, 3, 7 }, 10 });
    voxels.push({ { 8, 3, 9 }, 10 });
    voxels.push({ { 6, 3, 7 }, 10 });
    voxels.push({ { 9, 3, 6 }, 9 });
    voxels.push({ { 7, 3, 6 }, 9 });
    voxels.push({ { 9, 3, 8 }, 9 });
    voxels.push({ { 9, 3, 9 }, 9 });
    voxels.push({ { 10, 3, 9 }, 9 });
    voxels.push({ { 10, 3, 8 }, 9 });
    voxels.push({ { 9, 3, 5 }, 9 });
    voxels.push({ { 10, 3, 5 }, 9 });
    voxels.push({ { 10, 3, 6 }, 9 });
    voxels.push({ { 6, 3, 6 }, 9 });
    voxels.push({ { 7, 3, 5 }, 9 });
    voxels.push({ { 6, 3, 5 }, 9 });
    voxels.push({ { 7, 4, 8 }, 4 });
    voxels.push({ { 7, 4, 9 }, 4 });
    voxels.push({ { 7, 5, 8 }, 4 });
    voxels.push({ { 7, 5, 9 }, 4 });
    voxels.push({ { 6, 6, 8 }, 4 });
    voxels.push({ { 6, 6, 9 }, 4 });
    voxels.push({ { 5, 6, 8 }, 4 });
    voxels.push({ { 5, 6, 9 }, 4 });
    voxels.push({ { 4, 6, 8 }, 4 });
    voxels.push({ { 4, 6, 9 }, 4 });
    voxels.push({ { -31, 2, -8 }, 8 });
    voxels.push({ { 9, 6, -12 }, 6 });
    voxels.push({ { 9, 6, -11 }, 6 });
    voxels.push({ { 9, 6, -10 }, 6 });
    voxels.push({ { 9, 6, -9 }, 6 });
    voxels.push({ { 7, 0, -3 }, 4 });
    voxels.push({ { 8, 0, -3 }, 4 });
    voxels.push({ { 7, 1, -3 }, 4 });
    voxels.push({ { 8, 1, -3 }, 4 });
    voxels.push({ { -21, 2, -8 }, 6 });
    voxels.push({ { 2, 4, -8 }, 9 });
    voxels.push({ { 2, 4, -7 }, 9 });
    voxels.push({ { 7, 4, -11 }, 3 });
    voxels.push({ { 7, 4, -12 }, 3 });
    voxels.push({ { 8, 6, -12 }, 10 });
    voxels.push({ { 8, 6, -9 }, 10 });
    voxels.push({ { 8, 6, -11 }, 10 });
    voxels.push({ { 8, 6, -10 }, 10 });
    portals.create(2);
    portals.push({ { 1.999f, 5.46093f, 6.43585f }, { -1, 0, 0 }, 0.6f });
    portals.push({ { -39.999f, 7.67798f, -4.46772f }, { 1, 0, 0 }, 0.6f });

    for (size_t i = 0; i < lights.length(); ++i) {
        lightBuffer[i] = lights[i];
        lightBuffer[i].color.x = 5 * (rand() / (float)RAND_MAX - 0.5f);
        lightBuffer[i].color.y = 5 * (rand() / (float)RAND_MAX - 0.5f);
        lightBuffer[i].color.z = 5 * (rand() / (float)RAND_MAX - 0.5f);
    }
}

void MainView::gameOnKey(int key, int scancode, int action, int mods) {

    if (key == Qt::Key_Space) {
            if (velocityY == 0) {
                velocityY = jumpVelocity;
            }
            else if (doubleJumpReady) {
                velocityY = jumpVelocity;
                doubleJumpReady = false;
            }
    }
    if (key == Qt::Key_P) {
        gameMode = PlayMode;
        qDebug() << "now in Play Mode\n";
        printf("now in Play Mode\n");
    }
    if (key == Qt::Key_B) {
        gameMode = BuildMode;
        qDebug() << "now in Build Mode\n";
        printf("now in Build Mode\n");
    }

    if (gameMode == BuildMode) {
        switch (key) {
        case Qt::Key_0:
        case Qt::Key_1:
        case Qt::Key_2:
        case Qt::Key_3:
        case Qt::Key_4:
        case Qt::Key_5:
        case Qt::Key_6:
        case Qt::Key_7:
        case Qt::Key_8:
        case Qt::Key_9:
            material = (uint)(1 + key - Qt::Key_0);
            printPickedMaterial();
            break;
        default: break;
        }
    }
}

void MainView::gameOnMouseMove(double newX, double newY) {
    double dX = newX - width()/2;
    double dY = newY - height()/2;


    const double sensitivity = 0.004;

    cameraPitch -= (float)(sensitivity * dX);
    cameraYaw -= (float)(sensitivity * dY);
    if (cameraYaw >= 0.99f * PI / 2) {
        cameraYaw = 0.99f * PI / 2;
    }
    else if (cameraYaw <= -0.99f * PI / 2) {
        cameraYaw = -0.99f * PI / 2;
    }

    while (cameraPitch > PI) {
        cameraPitch -= 2*PI;
    }
    while(cameraPitch < -PI) {
        cameraPitch += 2*PI;
    }

    mat4 rot = mat4(1);
    rot = rotate(rot, cameraPitch, vec3(0, 1, 0));
    rot = rotate(rot, cameraYaw, vec3(1, 0, 0));
    cameraDir = normalize(vec3(rot * vec4(0, 0, -1, 0)));
    cameraRight = normalize(cross(cameraDir, cameraUp));
}
void MainView::gameOnMouseButton(int button, int action, int mods) {
    Ray r1 = { cameraPos, cameraDir };
    Ray r = trace(r1);
    if (gameMode == PlayMode) {
        Portal newPortal;
        newPortal.pos = r.pos;
        newPortal.normal = r.dir;
        newPortal.pos += rayEpsilon * r.dir;
        newPortal.radius = 0.7f;
        if (button == Qt::MouseButton::LeftButton) {
            portals[0] = newPortal;
        }
        if (button == Qt::MouseButton::RightButton) {
            portals[1] = newPortal;
        }
    }
    else if (gameMode == BuildMode) {
        if (button == Qt::MouseButton::LeftButton) {
            Voxel newV;
            newV.pos = (ivec3)floor((r.pos + 0.5f * r.dir));
            newV.material = material;
            voxels.push(newV);
        }
        if (button == Qt::MouseButton::RightButton) {
            float hitDist = floatMax;
            float closestDist = hitDist;
            size_t voxIdx = voxels.length();
            for (size_t i = 0; i < voxels.length(); ++i) {
                Voxel voxel = voxels[i];
                float d = intersect(r1, voxel);
                if (d > 0 && d < hitDist) {
                    if (closestDist > d) {
                        closestDist = d;
                        voxIdx = i;
                    }
                }
            }

            if (voxIdx < voxels.length())
                voxels.remove(voxIdx);
        }
    }
}
void MainView::gameOnMouseWheel(double dX, double dY) {
    if (gameMode == PlayMode) {
        float delta = 1.1f;
        if (dY > 0) cameraFoveaDist *= delta;
        if (dY < 0) cameraFoveaDist /= delta;
    }
    else if (gameMode == BuildMode) {
        if (dY > 0) material++;
        if (dY < 0) material--;

        if (material < 1) material = 1;
        if (material > 10) material = 10;

        printPickedMaterial();
    }
}
void MainView::gameOnInit() {
    iTimer.start();
    // Create a framebuffer for the raytracer output
    makeCurrent();
    raytraceOutputTexture = createTexture(NULL, 256, 256, GL_RGB16F);
    glGenFramebuffers(1, &raytraceOutputFramebuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, raytraceOutputFramebuffer);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, raytraceOutputTexture, 0);
    assert(glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE);
    glBindFramebuffer(GL_FRAMEBUFFER, defaultFramebufferObject());

    const char* textureFiles[] = {
        ":/textures/dirt.png",          // 0
        ":/textures/wood_dark.png",     // 1
        ":/textures/wood.png",          // 2
        ":/textures/stone.png",         // 3
        ":/textures/chisled_stone.png", // 4
        ":/textures/bricks.png",        // 5
        ":/textures/quartz.png",        // 6
        ":/textures/purple.png",        // 7
        ":/textures/candy.png",         // 8
    };

    uint numTextures = sizeof(textureFiles) / sizeof(textureFiles[0]);
    textureAtlas = loadTextureArray(textureFiles, numTextures, GL_RGB8);

    raytraceShader = loadShader(":/shaders/rayvert.glsl", ":/shaders/rayfrag.glsl");
    paintShader = loadShader(":/shaders/paintvert.glsl", ":/shaders/paintfrag.glsl");

    vec2 vertData[] = {
        { -1, 1 },
        { -1,-1 },
        {  1, 1 },
        {  1,-1 }
    };
    glGenVertexArrays(1, &fullscreenQuadVAO);
    glBindVertexArray(fullscreenQuadVAO);
    fullscreenQuad = createGpuBuffer(vertData, sizeof(vertData));
    bindGpuBuffer(fullscreenQuad, GL_ARRAY_BUFFER, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, false, sizeof(vec2), 0);

    lights.thing = this;
    materials.thing = this;
    planes.thing = this;
    spheres.thing = this;
    voxels.thing = this;
    portals.thing = this;

    loadScene();
}

void MainView::gameOnUpdate(double dt) {
    dt = iTimer.nsecsElapsed()/1000000000.0;
    iTimer.restart();
    t += dt;

    float moveSpeed = (float)dt * 5;
    if (shiftIsDown)
        moveSpeed *= 2.0f;

    vec3 moveDir = vec3(0);
    if (wIsDown) {
        moveDir.z += 1;
    }
    if (sIsDown) {
        moveDir.z -= 1;
    }
    if (aIsDown) {
        moveDir.x -= 1;
    }
    if (dIsDown) {
        moveDir.x += 1;
    }
    if (ctrlIsDown) {
        moveDir.y -= 1;
    }

    if (spaceIsDown) {
        moveDir.y += 1;
    }

    if (gameMode == PlayMode)
        moveDir.y = 0;
    if (moveDir != vec3(0))
        moveDir = moveSpeed * normalize(moveDir);

    vec3 deltaPos =
        moveDir.x * cameraRight +
        moveDir.y * cameraUp +
        moveDir.z * cross(cameraUp, cameraRight);

    if (gameMode == PlayMode) {
        deltaPos.y = 0;

        vec3 dpos = vec3(deltaPos.x, velocityY * (float)dt, deltaPos.z);
        Ray cameraRay = { cameraPos, normalize(dpos) };
        int portalInIndex = getClosestPortal(cameraPos);
        Portal portalIn = portals[(size_t)portalInIndex];
        Portal portalOut = portals[(size_t)1 - portalInIndex];
        float cameraDistanceToPortal = intersect(cameraRay, portalIn);
        if (cameraDistanceToPortal < 0.5f) {

            portalIn.normal = -portalIn.normal;
            mat3 M1 = getPortalMatrix(portalIn);
            mat3 M2 = getPortalMatrix(portalOut);

            cameraPos = cameraRay.pos + cameraRay.dir * cameraDistanceToPortal;
            cameraPos = portalOut.pos + inverse(M2) * M1 * (cameraPos - portalIn.pos);
            cameraDir = normalize(inverse(M2) * M1 * cameraDir);
            cameraPos += cameraRay.dir * 0.1f;
            cameraYaw = atan(cameraDir.y);
            cameraPitch = PI + atan2(cameraDir.x, cameraDir.z);
            cameraPos += portalOut.normal * 0.1f;
        }

        if (velocityY > 0) {
            cameraPos = moveWithCollisionCheck(cameraPos, vec3(0, (float)dt * velocityY, 0));
        }
        else if (velocityY < 0) {
            vec3 feetPos0 = cameraPos - vec3(0, playerHeight, 0);
            vec3 feetPos1 = moveWithCollisionCheck(feetPos0, vec3(0, (float)dt * velocityY, 0), 0.01f);
            cameraPos += feetPos1 - feetPos0;
            if (distance(feetPos0, feetPos1) < 0.001f) {
                velocityY = 0;
                doubleJumpReady = true;
            }
        }

        if (deltaPos.x != 0)
            cameraPos = moveWithCollisionCheck(cameraPos, vec3(deltaPos.x, 0, 0), 0.1f);
        if (deltaPos.z != 0)
            cameraPos = moveWithCollisionCheck(cameraPos, vec3(0, 0, deltaPos.z), 0.1f);

        float headDist = getDistanceToNearestObject(cameraPos, vec3(0, 1, 0));
        if (headDist < 0.01f) {
            velocityY = min(0.0f, velocityY);
        }
        float feetDist = getDistanceToNearestObject(cameraPos, vec3(0, -1, 0));
        float fallingDist = feetDist;
        float edgeTolerance = 0.25f;
        fallingDist = min(fallingDist, getDistanceToNearestObject(cameraPos + vec3(-edgeTolerance, 0, -edgeTolerance), vec3(0, -1, 0)));
        fallingDist = min(fallingDist, getDistanceToNearestObject(cameraPos + vec3(-edgeTolerance, 0, +edgeTolerance), vec3(0, -1, 0)));
        fallingDist = min(fallingDist, getDistanceToNearestObject(cameraPos + vec3(+edgeTolerance, 0, -edgeTolerance), vec3(0, -1, 0)));
        fallingDist = min(fallingDist, getDistanceToNearestObject(cameraPos + vec3(+edgeTolerance, 0, +edgeTolerance), vec3(0, -1, 0)));
        if (fallingDist > playerHeight + 0.1f) {
            velocityY -= (float)dt * gravity;
        }
        if (feetDist < playerHeight) {
            headDist = getDistanceToNearestObject(cameraPos, vec3(0, -1, 0));
            cameraPos = cameraPos + feetDist * vec3(0, -1, 0) + vec3(0, playerHeight, 0);
            velocityY = max(velocityY, 0.0f);
            doubleJumpReady = true;
        }
    }
    else {
        cameraPos += deltaPos;
    }

    for (size_t i = 0; i < lights.length(); ++i) {
        Light l = lights[i];
        float freqx = lightBuffer[i].color.x;
        float freqz = lightBuffer[i].color.y;
        float amplitudex = max(0.4f, 0.4f * (freqx + freqz) * lightBuffer[i].color.z);
        float amplitudez = max(0.4f, 0.8f * (freqz - freqz) * lightBuffer[i].color.z);
        l.pos.x = lightBuffer[i].pos.x + amplitudex * cos(freqx * t);
        l.pos.z = lightBuffer[i].pos.z + amplitudez * sin(freqz * t);
        lights[i] = l;
    }

    glBindFramebuffer(GL_FRAMEBUFFER, raytraceOutputFramebuffer);
    glViewport(0, 0, 256, 256);
    //glClear(GL_COLOR_BUFFER_BIT);

    bindShader(raytraceShader);
    lights.bind(GL_SHADER_STORAGE_BUFFER, 0);
    materials.bind(GL_SHADER_STORAGE_BUFFER, 1);
    planes.bind(GL_SHADER_STORAGE_BUFFER, 2);
    spheres.bind(GL_SHADER_STORAGE_BUFFER, 3);
    voxels.bind(GL_SHADER_STORAGE_BUFFER, 4);
    portals.bind(GL_SHADER_STORAGE_BUFFER, 5);
    bindTextureArray(textureAtlas, 0);

    mat4 view = lookAt(cameraPos, cameraPos + cameraDir, cameraUp);
    setUniform(raytraceShader, 0, vec2(width(), height()));
    setUniform(raytraceShader, 1, cameraFoveaDist);
    setUniform(raytraceShader, 2, cameraPos);
    setUniform(raytraceShader, 3, mat3(inverse(view)));
    setUniform(raytraceShader, 8, (float)t);
    setUniform(raytraceShader, 9, 0);
    glBindVertexArray(fullscreenQuadVAO);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    glEnable(GL_FRAMEBUFFER_SRGB);
    glBindFramebuffer(GL_FRAMEBUFFER, defaultFramebufferObject());
    glViewport(0, 0, width(), height());
    bindShader(paintShader);
    setUniform(paintShader, 0, 0);
    setUniform(paintShader, 1, vec2(width(), height()));
    bindTexture(raytraceOutputTexture, 0);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    //glDisable(GL_FRAMEBUFFER_SRGB);
}

